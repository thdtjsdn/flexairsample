package services;

/*
 * Created on 3/31/2006 - modified 10/02/2009
 *
 * SimpleService class demonstrates service
 * Flex training app
 */

/**
 *@author David Gassner, extended from code by Robert Crooks, Matthew Boles
 *simplified by John Mattos
 *
 * simple service for Flex 3 client
 * can be called as remote object service
 */

import java.util.HashMap;
import java.util.Map;

public class SimpleService {

	// properties
	private String helloString="Hello from a Simple Service!";
	private Map[] menuInfo = new HashMap[2];

	// constructors
	public SimpleService() {}

	//methods
	
	/**
	 *A method that returns a simple string
 	 */
	public String outMethod()
	{
		return helloString;
	}

	/**
	 *A method that returns static complex data
	 */ 
	public Map[] arrayOutMethod()
	{
		Map menu1=new HashMap();
		Map menu2=new HashMap();
		menu1.put("starter","Smoked Salmon");
		menu1.put("main","Filet");
		menu1.put("dessert","Key Lime Pie");
		menu2.put("starter","Calamari");
		menu2.put("main","Curried Lamb");
		menu2.put("dessert","Berry Pie");
		menuInfo[0]=menu1;
		menuInfo[1]=menu2;
		return menuInfo;
	}
	
	/**
	 *A method that received 2 Strings and returns a concatenated String
	 */ 
	public String multArgsMethod(String oneArg, String twoArg)
	{
		return ("The String arguments are: " + oneArg + 
				" and " + twoArg );
	}
}
